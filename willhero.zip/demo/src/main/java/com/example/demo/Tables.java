package com.example.demo;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import  javafx.stage.Stage;
import javafx.util.Duration;

public class Tables extends Application{
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        AnchorPane screen1=new AnchorPane();

        ImageView hero=new ImageView("file:///Users/xanirudhsharmax/Desktop/images/0805-removebg-preview.png");
        hero.setFitWidth(100);
        hero.setPreserveRatio(true);
        hero.setSmooth(true);
        hero.setCache(true);
        hero.setLayoutX(50);
        hero.setLayoutY(100);

        TranslateTransition transition=new TranslateTransition();
        transition.setNode(hero);
        transition.setDuration(Duration.millis(600));
        transition.setCycleCount(TranslateTransition.INDEFINITE);
        transition.setByY(90);
        transition.setAutoReverse(true);
        transition.play();

        Button btn = new Button("click me");
        Button btn2 = new Button("restart me");
        btn2.setLayoutX(20);btn2.setLayoutY(30);
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                TranslateTransition transition1=new TranslateTransition();
                transition1.setNode(hero);
                transition1.setDuration(Duration.millis(600));
                transition1.setCycleCount(1);
                transition1.setByX(40);
                //hero.setLayoutX(hero.getLayoutX()+10);
                transition1.play();
            }
        });
        btn2.setOnAction(e -> {
            hero.setLayoutX(50);
            //hero.setX(100);
            //hero.setY(50);
            hero.setLayoutY(100);

        });

        screen1.getChildren().addAll(hero, btn, btn2);
        Scene scene = new Scene(screen1,600,500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}


