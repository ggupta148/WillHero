package com.example.demo;

import java.io.Serializable;

public class savegame implements Serializable {
    int heropos;
    int heroscore;
    int coin;
    int wepon;

}
