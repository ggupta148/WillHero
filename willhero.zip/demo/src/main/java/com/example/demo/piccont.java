package com.example.demo;
import javafx.animation.*;
import javafx.beans.property.DoubleProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;
class hero{
    @FXML
    private ImageView hero;

    public ImageView getHero() {
        return hero;
    }
    public void setHero(ImageView hero) {
        this.hero = hero;
    }
    public int  getHeroX(){
        return (int)hero.getX();
    }
    public int  getHeroY(){
        return (int)hero.getY();
    }
    public void hasWepon(int x){
        int haswepon=x;
    }
    public int getHerolayoutX(){
        return (int)hero.getLayoutX();
    }
    public int getHerolayoutY(){
        return (int)hero.getLayoutY();
    }
    public int getTranslationX(){
        return (int)hero.getTranslateX();
    }
    public int getTranslationY(){
        return (int)hero.getTranslateY();
    }
}

class coin{
    @FXML
    private ImageView coin;
    @FXML
    private ImageView coin1;
    @FXML
    private ImageView coin2;
    @FXML
    private ImageView coin3;
    @FXML
    private ImageView coin4;
    @FXML
    private ImageView coin5;
    @FXML
    private ImageView coin6;
    @FXML
    private ImageView coin7;
    @FXML
    private ImageView coin8;
    @FXML
    private ImageView coin9;
    @FXML
    private ImageView coin10;
    @FXML
    private ImageView coin11;
    @FXML
    private ImageView coin161;
    @FXML
    private ImageView coin12;
    @FXML
    private ImageView coin13;
    @FXML
    private ImageView coin14;
    @FXML
    private ImageView coin15;
    @FXML
    private ImageView coin16;
    @FXML
    private ImageView coin17;
    @FXML
    private ImageView coin18;
    @FXML
    private ImageView coin19;
    @FXML
    private ImageView coin20;

    public ImageView getCoin() {
        return coin;
    }

    public void setCoin(ImageView coin) {
        this.coin = coin;
    }

    public ImageView getCoin1() {
        return coin1;
    }

    public void setCoin1(ImageView coin1) {
        this.coin1 = coin1;
    }

    public ImageView getCoin2() {
        return coin2;
    }

    public void setCoin2(ImageView coin2) {
        this.coin2 = coin2;
    }

    public ImageView getCoin3() {
        return coin3;
    }

    public void setCoin3(ImageView coin3) {
        this.coin3 = coin3;
    }

    public ImageView getCoin4() {
        return coin4;
    }

    public void setCoin4(ImageView coin4) {
        this.coin4 = coin4;
    }

    public ImageView getCoin5() {
        return coin5;
    }

    public void setCoin5(ImageView coin5) {
        this.coin5 = coin5;
    }

    public ImageView getCoin6() {
        return coin6;
    }

    public void setCoin6(ImageView coin6) {
        this.coin6 = coin6;
    }

    public ImageView getCoin7() {
        return coin7;
    }

    public void setCoin7(ImageView coin7) {
        this.coin7 = coin7;
    }

    public ImageView getCoin8() {
        return coin8;
    }

    public void setCoin8(ImageView coin8) {
        this.coin8 = coin8;
    }

    public ImageView getCoin9() {
        return coin9;
    }

    public void setCoin9(ImageView coin9) {
        this.coin9 = coin9;
    }

    public ImageView getCoin10() {
        return coin10;
    }

    public void setCoin10(ImageView coin10) {
        this.coin10 = coin10;
    }

    public ImageView getCoin11() {
        return coin11;
    }

    public void setCoin11(ImageView coin11) {
        this.coin11 = coin11;
    }

    public ImageView getCoin161() {
        return coin161;
    }

    public void setCoin161(ImageView coin161) {
        this.coin161 = coin161;
    }

    public ImageView getCoin12() {
        return coin12;
    }

    public void setCoin12(ImageView coin12) {
        this.coin12 = coin12;
    }

    public ImageView getCoin13() {
        return coin13;
    }

    public void setCoin13(ImageView coin13) {
        this.coin13 = coin13;
    }

    public ImageView getCoin14() {
        return coin14;
    }

    public void setCoin14(ImageView coin14) {
        this.coin14 = coin14;
    }

    public ImageView getCoin15() {
        return coin15;
    }

    public void setCoin15(ImageView coin15) {
        this.coin15 = coin15;
    }

    public ImageView getCoin16() {
        return coin16;
    }

    public void setCoin16(ImageView coin16) {
        this.coin16 = coin16;
    }

    public ImageView getCoin17() {
        return coin17;
    }

    public void setCoin17(ImageView coin17) {
        this.coin17 = coin17;
    }

    public ImageView getCoin18() {
        return coin18;
    }

    public void setCoin18(ImageView coin18) {
        this.coin18 = coin18;
    }

    public ImageView getCoin19() {
        return coin19;
    }

    public void setCoin19(ImageView coin19) {
        this.coin19 = coin19;
    }

    public ImageView getCoin20() {
        return coin20;
    }

    public void setCoin20(ImageView coin20) {
        this.coin20 = coin20;
    }
    public void vanishcoin(ImageView coinx){
        coinx.setVisible(false);
    }
}


class orc{
    public int  getOrcX(ImageView x){
        return (int)x.getX();
    }
    public int  getOrcY(ImageView x){
        return (int)x.getY();
    }
    public int getOrclayoutX(ImageView x){
        return (int)x.getLayoutX();
    }
    public int getOrclayoutY(ImageView x){
        return (int)x.getLayoutY();
    }
    public int getOrcTranslationX(ImageView x){
        return (int)x.getTranslateX();
    }
    public int getOrcTranslationY(ImageView x){
        return (int)x.getTranslateY();
    }
}
class greenorc extends orc{
    @FXML
    private ImageView orc;
    @FXML
    private  ImageView orc1;

    public ImageView getOrc() {
        return orc;
    }

    public void setOrc(ImageView orc) {
        this.orc = orc;
    }

    public ImageView getOrc1() {
        return orc1;
    }

    public void setOrc1(ImageView orc1) {
        this.orc1 = orc1;
    }

}

class redorc extends orc{
    @FXML
    private ImageView orc2;
    @FXML
    private ImageView orc3;

    public ImageView getOrc2() {
        return orc2;
    }

    public void setOrc2(ImageView orc2) {
        this.orc2 = orc2;
    }
    public ImageView getOrc3() {
        return orc3;
    }

    public void setOrc3(ImageView orc3) {
        this.orc3 = orc3;
    }
}
class bossorc extends orc{
    @FXML
    private  ImageView boss;

    public ImageView getBoss() {
        return boss;
    }

    public void setBoss(ImageView boss) {
        this.boss = boss;
    }

}
class gameobject{
    protected piccont game;
    protected gameobject(piccont game) {
        this.game=game;
    }

    public int  getislandX(ImageView x){
        return (int)x.getX();
    }
    public int  getislandY(ImageView x){
        return (int)x.getY();
    }
    public int getislandlayoutX(ImageView x){
        return (int)x.getLayoutX();
    }
    public int getislandlayoutY(ImageView x){
        return (int)x.getLayoutY();
    }
    public int getislandTranslationX(ImageView x){
        return (int)x.getTranslateX();
    }
    public int getislandTranslationY(ImageView x){
        return (int)x.getTranslateY();
    }
}

class island extends gameobject{
    @FXML
    private ImageView island1;
    @FXML
    private ImageView island2;
    @FXML
    private ImageView island3;
    @FXML
    private ImageView island4;
    @FXML
    private ImageView island5;
    @FXML
    private ImageView island6;
    @FXML
    private ImageView island7;
    @FXML
    private ImageView island8;
    @FXML
    private ImageView island9;
    @FXML
    private ImageView island10;
    @FXML
    private ImageView island13;
    @FXML
    private ImageView island15;
    @FXML
    private ImageView island16;
    @FXML
    private ImageView island17;

    protected island(piccont game) {
        super(game);
    }

    public ImageView getIsland1() {
        return island1;
    }

    public void setIsland1(ImageView island1) {
        this.island1 = island1;
    }

    public ImageView getIsland2() {
        return island2;
    }

    public void setIsland2(ImageView island2) {
        this.island2 = island2;
    }

    public ImageView getIsland3() {
        return island3;
    }

    public void setIsland3(ImageView island3) {
        this.island3 = island3;
    }

    public ImageView getIsland4() {
        return island4;
    }

    public void setIsland4(ImageView island4) {
        this.island4 = island4;
    }

    public ImageView getIsland5() {
        return island5;
    }

    public void setIsland5(ImageView island5) {
        this.island5 = island5;
    }

    public ImageView getIsland6() {
        return island6;
    }

    public void setIsland6(ImageView island6) {
        this.island6 = island6;
    }

    public ImageView getIsland7() {
        return island7;
    }

    public void setIsland7(ImageView island7) {
        this.island7 = island7;
    }

    public ImageView getIsland8() {
        return island8;
    }

    public void setIsland8(ImageView island8) {
        this.island8 = island8;
    }

    public ImageView getIsland9() {
        return island9;
    }

    public void setIsland9(ImageView island9) {
        this.island9 = island9;
    }

    public ImageView getIsland10() {
        return island10;
    }

    public void setIsland10(ImageView island10) {
        this.island10 = island10;
    }

    public ImageView getIsland13() {
        return island13;
    }

    public void setIsland13(ImageView island13) {
        this.island13 = island13;
    }

    public ImageView getIsland15() {
        return island15;
    }

    public void setIsland15(ImageView island15) {
        this.island15 = island15;
    }

    public ImageView getIsland16() {
        return island16;
    }

    public void setIsland16(ImageView island16) {
        this.island16 = island16;
    }

    public ImageView getIsland17() {
        return island17;
    }

    public void setIsland17(ImageView island17) {
        this.island17 = island17;
    }
}

class sky extends gameobject{

    @FXML
    private ImageView sky;
    @FXML
    private ImageView sky1;
    @FXML
    private ImageView sky2;
    @FXML
    private ImageView sky3;

    protected sky(piccont game) {
        super(game);
    }

    public ImageView getSky() {
        return sky;
    }

    public void setSky(ImageView sky) {
        this.sky = sky;
    }

    public ImageView getSky1() {
        return sky1;
    }

    public void setSky1(ImageView sky1) {
        this.sky1 = sky1;
    }

    public ImageView getSky2() {
        return sky2;
    }

    public void setSky2(ImageView sky2) {
        this.sky2 = sky2;
    }

    public ImageView getSky3() {
        return sky3;
    }

    public void setSky3(ImageView sky3) {
        this.sky3 = sky3;
    }
}

class tresury extends gameobject{

    public tresury(piccont game) {
        super(game);
    }
    public int  gettresureX(ImageView x){
        return (int)x.getX();
    }
    public int  gettresureY(ImageView x){
        return (int)x.getY();
    }
    public int gettresurelayoutX(ImageView x){
        return (int)x.getLayoutX();
    }
    public int gettresurelayoutY(ImageView x){
        return (int)x.getLayoutY();
    }
    public int gettresureTranslationX(ImageView x){
        return (int)x.getTranslateX();
    }
    public int gettresureTranslationY(ImageView x){
        return (int)x.getTranslateY();
    }
}

class weaponchest extends tresury{
    protected weaponchest(piccont game) {
        super(game);
    }

    public ImageView getTresure() {
        return tresure;
    }

    public void setTresure(ImageView tresure) {
        this.tresure = tresure;
    }

    public ImageView getTresure2() {
        return tresure2;
    }

    public void setTresure2(ImageView tresure2) {
        this.tresure2 = tresure2;
    }

    @FXML
    private ImageView tresure;
    @FXML
    private ImageView tresure2;

}
class coinchest extends tresury{
    protected coinchest(piccont game) {
        super(game);
    }

    public ImageView getTresure1() {
        return tresure1;
    }

    public void setTresure1(ImageView tresure1) {
        this.tresure1 = tresure1;
    }

    @FXML
    private ImageView tresure1;

}
class tnt extends gameobject{
    @FXML
    private ImageView tnt;
    @FXML
    private ImageView tnt1;
    @FXML
    private ImageView tnt2;

    protected tnt(piccont game) {
        super(game);
    }

    public ImageView getTnt() {
        return tnt;
    }

    public void setTnt(ImageView tnt) {
        this.tnt = tnt;
    }
}
class weapon{
    public void hasWepon(int x){
        int haswepon=x;
    }
    public void visibilityoff(ImageView x){
        x.setVisible(false);
    }
    public void visibilityon(ImageView x){
        x.setVisible(true);
    }
    public void attack(ImageView x){
        RotateTransition t = new RotateTransition();
        t.setNode(x);
        t.setDuration(Duration.millis(500));
        t.setCycleCount(1);
        t.setInterpolator(Interpolator.LINEAR);
        t.setByAngle(360);
        t.setAxis(Rotate.Z_AXIS);
        t.play();

    }
}
class hammer extends weapon{
    public ImageView getHammer() {
        return hammer;
    }

    public void setHammer(ImageView hammer) {
        this.hammer = hammer;
    }

    @FXML
    private ImageView hammer;

}
class sword extends weapon{
    @FXML
    private ImageView sword;

    public ImageView getSword() {
        return sword;
    }

    public void setSword(ImageView sword) {
        this.sword = sword;
    }
}
class player {
    @FXML
    private Button choosehammer;
    @FXML
    private Button choosesword;
    @FXML
    private Label myscore;
    @FXML
    private Label mycoin;
    private String name;

    public Button getChoosehammer() {
        return choosehammer;
    }

    public void setChoosehammer(Button choosehammer) {
        this.choosehammer = choosehammer;
    }

    public Button getChoosesword() {
        return choosesword;
    }

    public void setChoosesword(Button choosesword) {
        this.choosesword = choosesword;
    }

    public Label getMyscore() {
        return myscore;
    }

    public void setMyscore(Label myscore) {
        this.myscore = myscore;
    }

    public Label getMycoin() {
        return mycoin;
    }

    public void setMycoin(Label mycoin) {
        this.mycoin = mycoin;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void updatescore(Label x){
        setMyscore(x);
    }
    public void updatecoin(Label x){
        setMycoin(x);
    }
}


public class piccont  implements Initializable ,Serializable{
    @FXML
    private ImageView orc;
    @FXML
    private ImageView teleport;
    @FXML
    private ImageView sky;
    @FXML
    private ImageView orc2;
    @FXML
    private  ImageView orc1;
    @FXML
    private  ImageView orc3;
    @FXML
    private  ImageView boss;
    @FXML
    private ImageView island1;
    @FXML
    private ImageView island2;
    @FXML
    private ImageView island3;
    @FXML
    private ImageView island4;
    @FXML
    private ImageView island5;
    @FXML
    private ImageView island6;
    @FXML
    private ImageView island7;
    @FXML
    private ImageView island8;
    @FXML
    private ImageView island9;
    @FXML
    private ImageView island10;
    @FXML
    private ImageView island13;
    @FXML
    private ImageView island15;
    @FXML
    private ImageView island16;
    @FXML
    private ImageView island17;
    @FXML
    private ImageView hero;
    @FXML
    private ImageView settings;
    @FXML
    private ImageView tresure;
    @FXML
    private ImageView tresure1;
    @FXML
    private ImageView tresure2;
    @FXML
    private Button pause;
    @FXML
    private Button choosehammer;
    @FXML
    private Button choosesword;

    @FXML
    private Button load;

    @FXML
    private ImageView tnt;
    @FXML
    private ImageView tnt1;
    @FXML
    private ImageView tnt2;
    @FXML
    private Label myscore;
    @FXML
    private Label mycoin;
    @FXML
    private ImageView coin1;
    @FXML
    private ImageView coin2;
    @FXML
    private ImageView coin3;
    @FXML
    private ImageView coin4;
    @FXML
    private ImageView coin5;
    @FXML
    private ImageView coin6;
    @FXML
    private ImageView coin7;
    @FXML
    private ImageView coin8;
    @FXML
    private ImageView coin9;
    @FXML
    private ImageView coin10;
    @FXML
    private ImageView coin11;
    @FXML
    private ImageView coin161;
    @FXML
    private ImageView coin12;
    @FXML
    private ImageView coin13;
    @FXML
    private ImageView coin14;
    @FXML
    private ImageView coin15;
    @FXML
    private ImageView coin16;
    @FXML
    private ImageView coin17;
    @FXML
    private ImageView coin18;
    @FXML
    private ImageView coin19;
    @FXML
    private ImageView coin20;
    @FXML
    private ImageView sword;
    @FXML
    private ImageView hammer;
    @FXML
    private ImageView ishammer;
    @FXML
    private ImageView issword;
    @FXML
    private ImageView sky1;
    @FXML
    private ImageView sky2;
    @FXML
    private ImageView sky3;
    @FXML
    private TextField savename;



    private Scene scene;
    private Stage stage;
    private Parent root;

    int my_score=0;


    public void Home(ActionEvent event) throws IOException {
//        root = FXMLLoader.load(getClass().getResource("Home.fxml"));
//        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//        scene = new Scene(root);
//        stage.setScene(scene);
//        stage.show();
//        timer.stop();
        manager obj2=new manager();
        savegame obj=new savegame();
        obj.heroscore=my_score;
        obj.heropos=(int)hero.getX();
        obj.coin=coin_count;
        obj.wepon=random;
        try {
            obj2.save(obj,savename.getText());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadGame(ActionEvent event) throws IOException {
        String fileName = savename.getText();
        manager manager=new manager();
        savegame obj=null;
        try {
            savegame loadedObject = (savegame)manager.load(fileName);
            myscore.setText("Score : "+Integer.toString(loadedObject.heroscore));
            my_score=loadedObject.heroscore;
            hero.setX(loadedObject.heropos);
            mycoin.setText(Integer.toString(loadedObject.coin));
            coin_count=loadedObject.coin;
            random = loadedObject.wepon;
            sword.setX(loadedObject.heropos);
            hammer.setX(loadedObject.heropos);
            island1.setX(-loadedObject.heropos);
            island2.setX(-loadedObject.heropos);
            island3.setX(-loadedObject.heropos);
            island4.setX(-loadedObject.heropos);
            island5.setX(-loadedObject.heropos);
            island6.setX(-loadedObject.heropos);
            island7.setX(-loadedObject.heropos);
            island8.setX(-loadedObject.heropos);
            island9.setX(-loadedObject.heropos);
            island10.setX(-loadedObject.heropos);
            island13.setX(-loadedObject.heropos);
            island15.setX(-loadedObject.heropos);
            island16.setX(-loadedObject.heropos);
            island17.setX(-loadedObject.heropos);
            sky1.setX(-loadedObject.heropos);
            sky2.setX(-loadedObject.heropos);
            sky3.setX(-loadedObject.heropos);
            orc.setX(-loadedObject.heropos);
            orc1.setX(-loadedObject.heropos);
            orc2.setX(-loadedObject.heropos);
            orc3.setX(-loadedObject.heropos);
            boss.setX(-loadedObject.heropos);
            tresure.setX(-loadedObject.heropos);
            tnt.setX(-loadedObject.heropos);
            tnt1.setX(-loadedObject.heropos);
            tnt2.setX(-loadedObject.heropos);
            tresure.setX(-loadedObject.heropos);
            tresure1.setX(-loadedObject.heropos);
            tresure2.setX(-loadedObject.heropos);
            coin1.setX(-loadedObject.heropos);
            coin2.setX(-loadedObject.heropos);
            coin3.setX(-loadedObject.heropos);
            coin4.setX(-loadedObject.heropos);
            coin5.setX(-loadedObject.heropos);
            coin6.setX(-loadedObject.heropos);
            coin7.setX(-loadedObject.heropos);
            coin8.setX(-loadedObject.heropos);
            coin9.setX(-loadedObject.heropos);
            coin10.setX(-loadedObject.heropos);
            coin11.setX(-loadedObject.heropos);
            coin12.setX(-loadedObject.heropos);
            coin13.setX(-loadedObject.heropos);
            coin14.setX(-loadedObject.heropos);
            coin15.setX(-loadedObject.heropos);
            coin16.setX(-loadedObject.heropos);
            coin17.setX(-loadedObject.heropos);
            coin18.setX(-loadedObject.heropos);
            coin19.setX(-loadedObject.heropos);
            coin20.setX(-loadedObject.heropos);
            coin161.setX(-loadedObject.heropos);

            System.out.println("mehul");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private double x;
    private double y;
    public void up(ActionEvent e){
        //System.out.println("UP");

        hero.setY(hero.getY()-30);
    }
    public void down(ActionEvent e){
        //System.out.println("down");
        hero.setY(hero.getY()+30);
    }
    public void left(ActionEvent e){
        //System.out.println("left");
        hero.setX((hero.getX()-10));
        teleport.setX(teleport.getX()+10);
        hammer.setX(hammer.getX()-10);
        sword.setX(sword.getX()-10);
        island1.setX(island1.getX()+10);
        island2.setX(island2.getX()+10);
        island3.setX(island3.getX()+10);
        island4.setX(island4.getX()+10);
        island5.setX(island5.getX()+10);
        island6.setX(island6.getX()+10);
        island7.setX(island7.getX()+10);
        island8.setX(island8.getX()+10);
        island9.setX(island9.getX()+10);
        island10.setX(island10.getX()+10);
        island15.setX(island15.getX()+10);
        island16.setX(island16.getX()+10);
        island17.setX(island17.getX()+10);
        island13.setX(island13.getX()+10);

        orc.setX(orc.getX()+10);
        orc1.setX(orc1.getX()+10);
        orc2.setX(orc2.getX()+10);
        orc3.setX(orc2.getX()+10);
        boss.setX(boss.getX()+10);
        tresure.setX(tresure.getX()+10);
        tnt.setX(tnt.getX()+10);
        tnt1.setX(tnt1.getX()+10);
        tnt2.setX(tnt2.getX()+10);
        tresure.setX(tresure.getX()+10);
        tresure1.setX(tresure1.getX()+10);
        tresure2.setX(tresure2.getX()+10);
        coin1.setX((coin1.getX()+10));
        coin2.setX((coin2.getX()+10));
        coin3.setX((coin3.getX()+10));
        coin4.setX((coin4.getX()+10));
        coin5.setX((coin5.getX()+10));
        coin6.setX((coin6.getX()+10));
        coin7.setX((coin7.getX()+10));
        coin8.setX((coin8.getX()+10));
        coin9.setX((coin9.getX()+10));
        coin10.setX((coin10.getX()+10));
        coin11.setX((coin1.getX()+10));
        coin12.setX((coin2.getX()+10));
        coin13.setX((coin3.getX()+10));
        coin14.setX((coin4.getX()+10));
        coin15.setX((coin5.getX()+10));
        coin16.setX((coin6.getX()+10));
        coin17.setX((coin7.getX()+10));
        coin18.setX((coin8.getX()+10));
        coin19.setX((coin9.getX()+10));
        coin20.setX((coin10.getX()+10));
        coin161.setX((coin161.getX()+10));

    }

    myTimer timer= new myTimer();


    public void right(ActionEvent e){
        timer.start();
//        System.out.println(storage);
           //hero.setLayoutX((hero.getLayoutX()+10));
          // System.out.println("HERO ->  "+hero.getLayoutX()+" "+hero.getLayoutY());
            System.out.println("Hero  pos ->"+hero.getX()+" "+hero.getY());
            System.out.println("ORC pos-> "+orc.getX()+" "+orc.getY());
            DoubleProperty doublePropertyY = hero.translateYProperty();
            DoubleProperty doublePropertyOY = orc.translateYProperty();
            double temp=doublePropertyY.getValue();
            System.out.println("Hero property y "+(int)temp);
            System.out.println("Orc property y "+doublePropertyOY.getValue());

            hero.setX(hero.getX()+10);

            sky1.setX(sky1.getX()-10);
            sky2.setX(sky2.getX()-10);
            sky3.setX(sky3.getX()-10);
            sword.setX(sword.getX()+10);
            hammer.setX(hammer.getX()+10);
            island1.setX(island1.getX()-10);
            island2.setX(island2.getX()-10);
            island3.setX(island3.getX()-10);
            island4.setX(island4.getX()-10);
            island5.setX(island5.getX()-10);
            island6.setX(island6.getX()-10);
            island7.setX(island7.getX()-10);
            island8.setX(island8.getX()-10);
            island9.setX(island9.getX()-10);
            island10.setX(island10.getX()-10);
            island15.setX(island15.getX()-10);
            island16.setX(island16.getX()-10);
            island17.setX(island17.getX()-10);
            island13.setX(island13.getX()-10);
             teleport.setX(teleport.getX()-10);
            orc.setX(orc.getX()-10);
            orc1.setX(orc1.getX()-10);
            orc2.setX(orc2.getX()-10);
            orc3.setX(orc3.getX()-10);
            boss.setX(boss.getX()-10);
            tresure.setX(tresure.getX()-10);
            tresure1.setX(tresure1.getX()-10);
            tresure2.setX(tresure2.getX()-10);
            tnt.setX(tnt.getX()-10);
            tnt1.setX(tnt.getX()-10);
            tnt2.setX(tnt2.getX()-10);
            coin1.setX((coin1.getX()-10));
            coin2.setX((coin2.getX()-10));
            coin3.setX((coin3.getX()-10));
            coin4.setX((coin4.getX()-10));
            coin5.setX((coin5.getX()-10));
            coin6.setX((coin6.getX()-10));
            coin7.setX((coin7.getX()-10));
            coin8.setX((coin8.getX()-10));
            coin9.setX((coin9.getX()-10));
            coin10.setX((coin10.getX()-10));
            coin11.setX((coin1.getX()-10));
            coin12.setX((coin2.getX()-10));
            coin13.setX((coin3.getX()-10));
            coin14.setX((coin4.getX()-10));
            coin15.setX((coin5.getX()-10));
            coin16.setX((coin6.getX()-10));
            coin17.setX((coin7.getX()-10));
            coin18.setX((coin8.getX()-10));
            coin19.setX((coin9.getX()-10));
            coin20.setX((coin10.getX()-10));
            coin161.setX((coin161.getX()-10));
            my_score+=1;
            myscore.setText("Score : "+Integer.toString(my_score));
            mycoin.setText((Integer.toString(coin_count)));
            RotateTransition atatck = new RotateTransition();
            RotateTransition atatck1= new RotateTransition();
             atatck.setNode(sword);
             atatck.setDuration(Duration.millis(500));
             atatck.setCycleCount(1);
             atatck.setInterpolator(Interpolator.LINEAR);
             atatck.setByAngle(360);
             atatck.setAxis(Rotate.Z_AXIS);
             atatck.play();
            atatck1.setNode(hammer);
            atatck1.setDuration(Duration.millis(500));
            atatck1.setCycleCount(1);
            atatck1.setInterpolator(Interpolator.LINEAR);
            atatck1.setByAngle(360);
            atatck1.setAxis(Rotate.Z_AXIS);
            atatck1.play();
            if(my_score>=100) {
                bossentry((int) my_score);
                // fall((int)hero.getX(),(int)hero.getY(),int);
            }
            if(my_score>=107&&my_score<=113){
                boss.setX(boss.getX()+10);
                if(my_score==112){
                    boss.setVisible(false);
                }
            }
            if(my_score==124) {
                gamewon();
            }
    }

    public void follow(){
        if(hero.getX()>50){
            orc.setX(orc.getX()+20);


        }
    }
    int coin_count=0;

//    public void attackwepon(int choice){
//        RotateTransition atatck = new RotateTransition();
//        RotateTransition atatck1= new RotateTransition();
//
//        if(choice==1) {
//           atatck.setNode(sword);
//           atatck.setDuration(Duration.millis(500));
//           atatck.setCycleCount(1);
//           atatck.setInterpolator(Interpolator.LINEAR);
//           atatck.setByAngle(360);
//           atatck.setAxis(Rotate.Z_AXIS);
//           atatck.play();
//       }else {
//           atatck1.setNode(hammer);
//           atatck1.setDuration(Duration.millis(500));
//           atatck1.setCycleCount(1);
//           atatck1.setInterpolator(Interpolator.LINEAR);
//           atatck1.setByAngle(360);
//           atatck1.setAxis(Rotate.Z_AXIS);
//           atatck1.play();
//       }
//
//    }

    public void hammerclick(ActionEvent e){
        if(haswepon==1){
            hammer.setVisible(true);
            sword.setVisible(false);
        }
    }
    public void swordclick(ActionEvent e){
        if(haswepon==1){
            sword.setVisible(true);
            hammer.setVisible(false);
        }
    }
    public void changeslide(){
        if(hero.getX()==460);

    }
    int check;
    public void bossentry(int heroX){

        if(heroX==100){
            TranslateTransition bossentry=new TranslateTransition();
            bossentry.setNode(boss);
            bossentry.setDuration(Duration.millis(100));
            bossentry.setCycleCount(1);
            bossentry.setByY(257);
            bossentry.play();
            check=0;
        }else if(check==0){
            TranslateTransition bossentry1=new TranslateTransition();
            bossentry1.setNode(boss);
            bossentry1.setDuration(Duration.millis(1000));
            bossentry1.setCycleCount(TranslateTransition.INDEFINITE);
            bossentry1.setByY(-100);
            bossentry1.setAutoReverse(true);
            bossentry1.play();
            check=1;
        }
    }

public void teleport(int heroX,int heroY){
        if(heroX==930 && heroY>110){
            my_score=110;
            hero.setX(1190);
            sword.setX(1190);
            hammer.setX(1190);
        }
    }


    public void fall(int heroX,int heroY,int orcX){
        TranslateTransition falling= new TranslateTransition();
        TranslateTransition fallinghero= new TranslateTransition();
        if((heroX == 150||heroX==160)  && heroY >=100){
           // System.out.println("fall");

            fallinghero.setNode(hero);
            fallinghero.setDelay(Duration.millis(5));
            fallinghero.setDuration(Duration.millis(900));
            fallinghero.setCycleCount(1);
            fallinghero.setByY(350);
            fallinghero.play();
           // hero.setY(300);
            gameOver();
        }else if((heroX == 350||heroX==360) &&  heroY >=100) {
            // System.out.println("fall");
            fallinghero.setNode(hero);
            fallinghero.setDelay(Duration.millis(5));
            fallinghero.setDuration(Duration.millis(900));
            fallinghero.setCycleCount(1);
            fallinghero.setByY(350);
            fallinghero.play();
            // hero.setY(300);
            gameOver();
            hero.setVisible(false);
            sword.setVisible(false);
            hammer.setVisible(false);
        }else if(orcX>160){
            OrcCollision.stop();
            falling.setNode(orc);
           falling.setDuration(Duration.millis(300));
           falling.setCycleCount(1);
           falling.setByY(350);
           falling.play();

        }else if(heroX == 590 &&  heroY >=100) {
            // System.out.println("fall");
            fallinghero.setNode(hero);
            fallinghero.setDelay(Duration.millis(5));
            fallinghero.setDuration(Duration.millis(900));
            fallinghero.setCycleCount(1);
            fallinghero.setByY(350);
            fallinghero.play();
            // hero.setY(300);
            gameOver();
            hero.setVisible(false);
            sword.setVisible(false);
            hammer.setVisible(false);
        }
        else if((heroX == 700 ||heroX==710) && heroY >=100) {
            // System.out.println("fall");
            fallinghero.setNode(hero);
            fallinghero.setDelay(Duration.millis(5));
            fallinghero.setDuration(Duration.millis(900));
            fallinghero.setCycleCount(1);
            fallinghero.setByY(350);
            fallinghero.play();
            // hero.setY(300);
            gameOver();
            hero.setVisible(false);
            sword.setVisible(false);
            hammer.setVisible(false);
        }
        else if(heroX == 940 &&  heroY >=100) {
            // System.out.println("fall");
            fallinghero.setNode(hero);
            fallinghero.setDelay(Duration.millis(5));
            fallinghero.setDuration(Duration.millis(900));
            fallinghero.setCycleCount(1);
            fallinghero.setByY(350);
            fallinghero.play();
            // hero.setY(300);
            gameOver();
            hero.setVisible(false);
            sword.setVisible(false);
            hammer.setVisible(false);
        }
    }

    TranslateTransition OrcCollision = new TranslateTransition();

    public void collisionOrc(int heroX, int orcX, int heroY, int orcY,int wepon){

        TranslateTransition OrcCollision1 = new TranslateTransition();
        if ((heroX==60 && heroX<=80) && orcX==-60 ){
           if(heroY-orcY<5) {
               if (wepon == 0) {
                   OrcCollision.setNode(orc);
                   OrcCollision.setDelay(Duration.millis(2));
                   OrcCollision.setCycleCount(1);
                   OrcCollision.setDuration(Duration.millis(200));
                   OrcCollision.setByX(70);
                   OrcCollision.play();
                   coin_count+=1;
               }
           }
           else if (heroY-orcY>=99){
               //hero.setVisible(false);
              // gameOver();
           }
        }else if (heroX==240 && orcX==-240 && heroX<260){
            if(heroY-orcY<5) {
                if (wepon == 0) {
                    OrcCollision1.setNode(orc1);
                    OrcCollision1.setDelay(Duration.millis(2));
                    OrcCollision1.setCycleCount(1);
                    OrcCollision1.setDuration(Duration.millis(200));
                    OrcCollision1.setByX(50);
                    OrcCollision1.play();
                    coin_count+=1;

                } else {
                    FadeTransition fadeorc = new FadeTransition();
                    fadeorc.setNode(orc1);
                    fadeorc.setFromValue(1);
                    fadeorc.setToValue(-1);
                    fadeorc.setCycleCount(1);
                    fadeorc.play();
                    coin_count+=1;
                    //orc1.setVisible(false);
                }
            }else if(heroY-orcY>=99){
                gameOver();
                hero.setVisible(false);
                sword.setVisible(false);
                hammer.setVisible(false);
            }
        }else if (heroX==370 && orcX==-370 && heroX<390){
            if(heroY-orcY<5) {
                if (wepon == 0) {
                    OrcCollision1.setNode(orc2);
                    OrcCollision1.setDelay(Duration.millis(2));
                    OrcCollision1.setCycleCount(1);
                    OrcCollision1.setDuration(Duration.millis(200));
                    OrcCollision1.setByX(50);
                    OrcCollision1.play();
                    coin_count+=1;
                } else {
                    FadeTransition fadeorc = new FadeTransition();
                    fadeorc.setNode(orc2);
                    fadeorc.setFromValue(1);
                    fadeorc.setToValue(-1);
                    fadeorc.setCycleCount(1);
                    fadeorc.play();
                    coin_count+=1;
                    //orc1.setVisible(false);
                }
            }else if(heroY-orcY>=99){
                hero.setVisible(false);
                sword.setVisible(false);
                hammer.setVisible(false);
                gameOver();
            }
        }else if (heroX==620 && orcX==-620 && heroX<640) {
            if( heroY-orcY<5 ) {
                if (wepon == 0) {
                    OrcCollision1.setNode(orc3);
                    OrcCollision1.setDelay(Duration.millis(2));
                    OrcCollision1.setCycleCount(1);
                    OrcCollision1.setDuration(Duration.millis(200));
                    OrcCollision1.setByX(50);
                    OrcCollision1.play();
                    coin_count+=1;
                } else {
                    FadeTransition fadeorc = new FadeTransition();
                    fadeorc.setNode(orc3);
                    fadeorc.setFromValue(1);
                    fadeorc.setToValue(-1);
                    fadeorc.setCycleCount(1);
                    fadeorc.play();
                    coin_count+=1;
                }
            } else if(heroY-orcY>=99) {
                hero.setVisible(false);
                sword.setVisible(false);
                hammer.setVisible(false);
                gameOver();
            }
        }

    }

    public void checkCollision(int heroposX,int heroposY){
        if(heroposX>=280 && heroposX<=300&&heroposY>110){
            tnt.setVisible(false);
            hero.setVisible(false);
            sword.setVisible(false);
            hammer.setVisible(false);
            gameOver();
        }else if(heroposX>=540&&heroposX<=550 &&heroposY>110){
            tnt1.setVisible(false);
            hero.setVisible(false);
            sword.setVisible(false);
            hammer.setVisible(false);
            gameOver();
        }else if(heroposX>=830&&heroposX<=840 &&heroposY>110){
            tnt2.setVisible(false);
            hero.setVisible(false);
            sword.setVisible(false);
            hammer.setVisible(false);
            gameOver();
        }
    }
    public void openChest(int heroX,int heroY,int b){

        if(heroX>=190 && heroX<=210 && heroY>110){
            tresure.setImage(new Image("file:///Users/xanirudhsharmax/Desktop/images/ChestOpen.png"));
            if(b==1){
                ishammer.setOpacity(1);
                hammer.setVisible(true);
                sword.setVisible(false);
                haswepon=1;

            }else if (b==0) {
                issword.setOpacity(1);
                sword.setVisible(true);
                hammer.setVisible(false);
                haswepon=1;
            }
        }else if(heroX>=410 && heroX<=430 &&  heroY>111 ){
            tresure1.setImage(new Image("file:///Users/xanirudhsharmax/Desktop/images/ChestOpen.png"));
            if(b==1){
               // ishammer.setOpacity(1);
               // hammer.setVisible(true);
                //haswepon=1;
                coin_count+=5;

            }else if(b==0) {
//                issword.setOpacity(1);
//                sword.setVisible(true);
//                haswepon=1;
                coin_count+=5;
            }

        }else if(heroX>=750 && heroX<=760 && heroY>110) {
            tresure2.setImage(new Image("file:///Users/xanirudhsharmax/Desktop/images/ChestOpen.png"));
            if (b == 0) {
                ishammer.setOpacity(1);
                hammer.setVisible(true);
                sword.setVisible(false);
                haswepon = 1;

            } else if (b == 1) {
                issword.setOpacity(1);
                sword.setVisible(true);
                hammer.setVisible(false);
                haswepon = 1;
            }
        }
    }


    public void vanish(int x, int y) {
        FadeTransition fadeup = new FadeTransition();
        FadeTransition fadedown = new FadeTransition();
//        int temp_count = 0;
        if (x >= 110.0&& y>=0&&y<=2 && x<=130.0) {
            fadeup.setNode(coin1);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();
            fadeup.setDelay(Duration.millis(500));
//            coin1.setVisible(false);
            coin_count++;
//            coin_count++;
        }else if (x >= 110.0 && y>=33&&y<=36 && x<=130.0) {
            fadedown.setNode(coin6);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.play();
            fadedown.setDelay(Duration.millis(500));
         //   coin6.setVisible(false);
            coin_count++;
        }else if (x >= 120.0 && y>=0&&y<=2 && x<=140.0) {
            fadeup.setNode(coin2);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();
            fadeup.setDelay(Duration.millis(500));
           // coin2.setVisible(false);
        coin_count++;
        }else if (x >= 120.0 && y>=33&&y<=36 && x<=140.0) {
            fadedown.setNode(coin7);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.setCycleCount(1);
            fadedown.play();
            fadeup.setDelay(Duration.millis(500));
           // coin7.setVisible(false);
            coin_count++;
        }else if (x >= 130.0 && y>=0&&y<=2 && x<=150.0) {
            fadeup.setNode(coin3);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();
            fadeup.setDelay(Duration.millis(500));
           // coin3.setVisible(false);
            coin_count++;
        } else if (x >= 130.0 && y>=33&&y<=36 && x<=150.0) {
            fadedown.setNode(coin8);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.setCycleCount(1);
            fadedown.play();fadeup.setDelay(Duration.millis(500));
//            coin8.setVisible(false);
            coin_count++;
        }else if (x >= 140.0 && y>=0&&y<=2 && x<=160.0) {
            fadeup.setNode(coin4);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();
            fadeup.setDelay(Duration.millis(500));
            //coin4.setVisible(false);
            coin_count++;
        } else if (x >= 140.0 && y>=33&&y<=36 && x<=160.0) {
            fadedown.setNode(coin9);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.setCycleCount(1);
            fadedown.play();fadeup.setDelay(Duration.millis(500));
//            coin9.setVisible(false);
            coin_count++;
        }else if (x >= 150.0 && y>=0&&y<=2 && x<=170.0) {
            fadeup.setNode(coin5);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();fadeup.setDelay(Duration.millis(500));
//            coin5.setVisible(false);
            coin_count++;
        } else if (x >= 150.0 && y>=33&&y<=36 && x<=170.0) {
            fadedown.setNode(coin10);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.setCycleCount(1);
            fadedown.play();fadeup.setDelay(Duration.millis(500));
//            coin10.setVisible(false);
            coin_count++;
        }
}
public void vanish1(int x,int y){
    FadeTransition fadeup = new FadeTransition();
    FadeTransition fadedown = new FadeTransition();
    if (x >= 450 && x<=470) {
        if (y>= 0 && y<=2 ) {
            coin11.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin16.setVisible(false);
            coin_count++;
        }
    }else if (x >= 460 && x<=480 ){
        if (y>= 0 && y<=2 ) {
            coin12.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin17.setVisible(false);
            coin_count++;
        }
    }else if (x >= 470 && x<=490 ){
        if (y>= 0 && y<=2 ) {
            coin13.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin18.setVisible(false);
            coin_count++;
        }
    }else if (x >= 480 && x<=500 ){
        if (y>= 0 && y<=2 ) {
            coin14.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin19.setVisible(false);
            coin_count++;
        }
    }else if (x >= 490 && x<=510 ){
        if (y>= 0 && y<=2 ) {
            coin15.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin20.setVisible(false);
            coin_count++;
        }
    }
}



    int  haswepon=0;
    int random = (int)(Math.random()*(1-0+1)+0);


//AnimationTimer collisionTimer = new AnimationTimer() {
//        @Override
//        public void handle(long now) {
////            checkCollision(hero,coin1);
//        }
//    };
    double storage;
   int timertime=0;
   private long prevtime;
    long  doublePropertyY;


    private class myTimer extends AnimationTimer{
        @Override
        public void handle(long now) {
            long dt=now-prevtime;
            DoubleProperty doublePropertyhero = hero.translateYProperty();
            DoubleProperty doublePropertyOrc = orc.translateYProperty();
            DoubleProperty doublePropertyOrcX = orc.translateXProperty();
            DoubleProperty doublePropertyOrc1 = orc1.translateYProperty();
              //  System.out.println(doublePropertyY.getValue());
                //timertime++;
            double orcstorage=doublePropertyOrc.getValue();
            double orcX=doublePropertyOrcX.getValue();
            double orc1storage=doublePropertyOrc1.getValue();
            storage=doublePropertyhero.getValue();
            //System.out.println(hero.getX());
            System.out.println("hero y : "+(int)storage);
            System.out.println("hero x "+hero.getX());
            System.out.println("orc translation :"+(int)orcX);

            //System.out.println("orc: "+doublePropertyOY.getValue());
            vanish((int)hero.getX(),(int)storage);
            vanish1((int)hero.getX(),(int)storage);
            collisionOrc((int)hero.getX(), (int)orc.getX(),(int)storage,(int)orcstorage,haswepon);
            collisionOrc((int)hero.getX(), (int)orc1.getX(),(int)storage,(int)orc1storage,haswepon);
            checkCollision((int)hero.getX(),(int)storage);
            openChest((int)hero.getX(),(int)storage,random);
            fall((int)hero.getX(),(int)storage,(int)orcX);
            teleport((int)hero.getX(),(int)storage);
        }
    }


        TranslateTransition translate5 = new TranslateTransition();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       // MovementController movementController=new MovementController(hero,scene);
//        myTimer timer = new myTimer();
//       timer.start();
        TranslateTransition translate = new TranslateTransition();
        TranslateTransition translate5 = new TranslateTransition();
        TranslateTransition swordtranslate=new TranslateTransition();
        TranslateTransition hammertranslate=new TranslateTransition();
        TranslateTransition translate1 = new TranslateTransition();
        TranslateTransition translate2 = new TranslateTransition();
        TranslateTransition translate3 = new TranslateTransition();
        TranslateTransition translate4 = new TranslateTransition();
        TranslateTransition orc3jump = new TranslateTransition();
        RotateTransition rotate=new RotateTransition();

        //timer.start();
        translate.setNode(orc);
        translate.setDuration(Duration.millis(600));
        translate.setCycleCount(TranslateTransition.INDEFINITE);
        translate.setByY(90);
        translate.setAutoReverse(true);
        translate.play();

        translate5.setNode(hero);
        translate5.setDuration(Duration.millis(700));
        //translate5.setDelay(Duration.millis(1000));
        translate5.setByY(120);
        translate5.setAutoReverse(true);
        translate5.setCycleCount(TranslateTransition.INDEFINITE);
        translate5.play();
        swordtranslate.setNode(sword);
        swordtranslate.setDuration(Duration.millis(700));
        swordtranslate.setByY(120);
        swordtranslate.setAutoReverse(true);
        swordtranslate.setCycleCount(TranslateTransition.INDEFINITE);
        swordtranslate.play();
        hammertranslate.setNode(hammer);
        hammertranslate.setDuration(Duration.millis(700));
        hammertranslate.setByY(120);
        hammertranslate.setAutoReverse(true);
        hammertranslate.setCycleCount(TranslateTransition.INDEFINITE);
        hammertranslate.play();



        translate1.setNode(orc2);
        translate1.setDuration(Duration.millis(800));
        translate1.setCycleCount(TranslateTransition.INDEFINITE);
        translate1.setByY(90);
        translate1.setAutoReverse(true);
        translate1.play();

        translate2.setNode(orc1);
        translate2.setDuration(Duration.millis(1000));
        translate2.setCycleCount(TranslateTransition.INDEFINITE);
        translate2.setByY(90);
        translate2.setAutoReverse(true);
        translate2.play();

        orc3jump.setNode(orc3);
        orc3jump.setDuration(Duration.millis(1000));
        orc3jump.setCycleCount(TranslateTransition.INDEFINITE);
        orc3jump.setByY(90);
        orc3jump.setAutoReverse(true);
        orc3jump.play();

        rotate.setNode(teleport);
        rotate.setDuration(Duration.millis(700));
        rotate.setCycleCount(TranslateTransition.INDEFINITE);
        rotate.setByAngle(360);
        rotate.setAxis(Rotate.Y_AXIS);
        rotate.play();


//        System.out.println("hero ->"+hero.getX()+" "+hero.getY());
//        System.out.println("orc ->"+orc.getX()+" "+orc.getY());
//        if(hero.getX()==100 || orc.getX()==-90.0){
//            FadeTransition fade = new FadeTransition();
//            fade.setNode(orc);
//            fade.setFromValue(1);
//            fade.setToValue(0);
//            fade.play();
//        }


//        FadeTransition fade = new FadeTransition();
//            fade.setNode(orc);
//            fade.setFromValue(1);
//            fade.setToValue(0);
//            fade.play();

//        translate3.setNode(island);
//        translate3.setDuration(Duration.millis(2000));
//        translate3.setCycleCount(TranslateTransition.INDEFINITE);
//        translate3.setByY(80);
//        translate3.setAutoReverse(true);
//        translate3.play();
//            collisionTimer.start();
    }
    Stage stage2= new Stage();
    public void Setting_(ActionEvent event) throws IOException {
//        Stage stage2 = new Stage();
        ImageView imageView  = new ImageView("file:///Users/xanirudhsharmax/Desktop/images/maxresdefault.jpg");
//        Label setting= new Label();
//        setting.setLayoutX(100);
//        setting.setLayoutY(100);
//        setting.setVisible(false);
//        setting.setText(" SETTINGS ");
//        setting.setMaxSize(250, 100);
//        setting.setOpacity(1);
//        setting.setFont(Font.font(18));
//        AnchorPane anchorPane1 = new AnchorPane();
//        anchorPane1.getChildren().addAll();
//        Scene scene = new Scene(anchorPane1);
//        stage2.show();


//        Scene scene = new Scene(anchorPane);
        Button button = new Button("resume");
        Button button1 = new Button("restart");
        Button button2 = new Button("Go to main menu");
        Button button3= new Button("Save");
        Label label = new Label();

        label.setText("SETTINGS");
        label.setLayoutX(50);
        label.setLayoutY(30);
        label.setFont(Font.font(30));
        label.setMaxSize(250, 100);
        label.toFront();
        button.setLayoutX(100);
        button.setLayoutY(90);
        button.toFront();
        button1.setLayoutX(100);
        button1.setLayoutY(130);
        button1.toFront();
        button2.setLayoutX(70);
        button2.setLayoutY(170);
        button2.toFront();
        button3.setLayoutX(70);
        button3.setLayoutY(190);
        button3.toFront();

//        root= FXMLLoader.load(getClass().getResource("settings.fxml"));
//        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
//        scene = new Scene(root);
//        stage.setScene(scene);
//        stage.show();
        button1.setOnAction(event1 -> {
            Parent root1= null;
            try {
                root1 = FXMLLoader.load(getClass().getResource("picture.fxml"));
                stage2=(Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root1);
                stage2.setScene(scene);
                stage2.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        button2.setOnAction(event2 ->{
            Parent root1= null;
            try {
                root1 = FXMLLoader.load(getClass().getResource("Home.fxml"));
                stage2=(Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root1);
                stage2.setScene(scene);
                stage2.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        AnchorPane anchorPane = new AnchorPane();
        anchorPane.getChildren().addAll(imageView, button, button1, button2,label);
        Scene scene = new Scene(anchorPane);
        stage2.setScene(scene);
        stage2.setTitle("Setting");
        stage2.setWidth(250);
        stage2.setHeight(300);
        stage2.setResizable(false);

        button.setOnAction(e ->{
            stage2.close();
        });

        stage2.show();
    }

    Stage stage1 = new Stage();
    public void gameOver(){

        ImageView imageView = new ImageView("file:///Users/xanirudhsharmax/Desktop/images/Screenshot_2022-01-03_at_12.27.20_AM-removebg-preview.png");

        Button restart = new Button("Restart");
        restart.setLayoutY(400);
        restart.setLayoutX(100);
        restart.toFront();
        Label error= new Label();
        Label show_score= new Label();
        Label show_highscore= new Label();
        error.setLayoutX(150);
        error.setLayoutY(360);
        error.setVisible(false);
        error.setText("NOT SUFFCIENT COINS");
        error.setMaxSize(250, 100);
        error.setOpacity(1);
        error.setFont(Font.font(18));
        show_score.setLayoutX(350);
        show_score.setLayoutY(360);
        show_score.setText("Your Score :"+Integer.toString(my_score));
        show_score.setFont(Font.font(25));
        show_highscore.setLayoutX(350);
        show_highscore.setLayoutY(400);
        int max=0;
        if (max<my_score){
            max=my_score;
        }
        show_highscore.setText("Highscore :"+Integer.toString(max));
        show_highscore.setFont(Font.font(25));
        error.setOpacity(1);


        Button cont= new Button("Continue");
        cont.setLayoutY(400);
        cont.setLayoutX(200);
        cont.toFront();

        restart.setOnAction(event -> {
            Parent root2= null;
            try {
                root2 = FXMLLoader.load(getClass().getResource("picture.fxml"));
                stage1=(Stage)((Node)event.getSource()).getScene().getWindow();
                scene=new Scene(root2);
                stage1.setScene(scene);
                stage1.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        AnchorPane anchorPane = new AnchorPane();
        anchorPane.getChildren().addAll(imageView,restart,cont,error,show_score,show_highscore);
        Scene scene = new Scene(anchorPane);
        stage1.setScene(scene);
        stage1.setTitle("game over");
        stage1.setWidth(710);
        stage1.setHeight(520);
        stage1.setResizable(false);

            cont.setOnAction(event -> {
                int count=0;
                if(count==0){
                    if (coin_count > 20) {
                        stage1.close();
                        count = 1;
                        hero.setVisible(true);
                        if (random == 0) {
                         sword.setVisible(true);
                        } else {
                         hammer.setVisible(true);
                    }
                    }
                } else {
                    error.setVisible(true);
                }
            });

        timer.stop();
        stage1.show();
    }
    Stage stage3=new Stage();
    public  void gamewon(){
        ImageView imageView = new ImageView("file:///Users/xanirudhsharmax/Desktop/won.jpg");
        Button restart = new Button("Restart");
        restart.setLayoutY(320);
        restart.setLayoutX(240);

        restart.setOnAction(event -> {
            Parent root= null;
            try {
                root = FXMLLoader.load(getClass().getResource("picture.fxml"));
                stage3=(Stage)((Node)event.getSource()).getScene().getWindow();
                scene=new Scene(root);
                stage3.setScene(scene);
                stage3.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.getChildren().addAll(restart,imageView);
        Scene scene = new Scene(anchorPane);
        Button btn =new Button();
        btn.setLayoutX(10);
        restart.toFront();
        stage3.setTitle("YOU WON");
        stage3.setScene(scene);
        stage3.setWidth(540);
        stage3.setHeight(390);
        stage3.show();
        timer.stop();
    }
}
