package com.example.demo;
import javafx.animation.*;
import javafx.beans.property.DoubleProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class piccont  implements Initializable {
    @FXML
    private ImageView orc;
    @FXML
    private ImageView orc2;
    @FXML
    private  ImageView orc1;
    @FXML
    private ImageView island1;
    @FXML
    private ImageView island2;
    @FXML
    private ImageView island3;
    @FXML
    private ImageView island4;
    @FXML
    private ImageView island5;
    @FXML
    private ImageView island6;
    @FXML
    private ImageView island7;
    @FXML
    private ImageView island8;
    @FXML
    private ImageView island9;
    @FXML
    private ImageView island10;
    @FXML
    private ImageView island11;
    @FXML
    private ImageView hero;
    @FXML
    private ImageView settings;
    @FXML
    private ImageView tresure;
    @FXML
    private ImageView tresure1;
    @FXML
    private Button pause;
    @FXML
    private Button choosehammer;
    @FXML
    private Button choosesword;
    @FXML
    private ImageView tnt;
    @FXML
    private ImageView tnt1;
    @FXML
    private Label myscore;
    @FXML
    private Label mycoin;
    @FXML
    private ImageView coin1;
    @FXML
    private ImageView coin2;
    @FXML
    private ImageView coin3;
    @FXML
    private ImageView coin4;
    @FXML
    private ImageView coin5;
    @FXML
    private ImageView coin6;
    @FXML
    private ImageView coin7;
    @FXML
    private ImageView coin8;
    @FXML
    private ImageView coin9;
    @FXML
    private ImageView coin10;
    @FXML
    private ImageView coin11;
    @FXML
    private ImageView coin12;
    @FXML
    private ImageView coin13;
    @FXML
    private ImageView coin14;
    @FXML
    private ImageView coin15;
    @FXML
    private ImageView coin16;
    @FXML
    private ImageView coin17;
    @FXML
    private ImageView coin18;
    @FXML
    private ImageView coin19;
    @FXML
    private ImageView coin20;
    @FXML
    private ImageView sword;
    @FXML
    private ImageView hammer;
    @FXML
    private ImageView ishammer;
    @FXML
    private ImageView issword;




    private Scene scene;
    private Stage stage;
    private Parent root;
    int my_score=0;

    public void Home(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Home.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    private double x;
    private double y;
    public void up(ActionEvent e){
        //System.out.println("UP");
        hero.setY(hero.getY()-30);
    }
    public void down(ActionEvent e){
        //System.out.println("down");
        hero.setY(hero.getY()+30);
    }
    public void left(ActionEvent e){
        //System.out.println("left");
        hero.setX((hero.getX()-10));
        sword.setX(sword.getX()-10);
        island1.setX(island1.getX()+10);
        island2.setX(island2.getX()+10);
        island3.setX(island3.getX()+10);
        island4.setX(island4.getX()+10);
        island5.setX(island5.getX()+10);
        island6.setX(island6.getX()+10);
        island7.setX(island7.getX()+10);
        island8.setX(island8.getX()+10);
        island9.setX(island9.getX()+10);
        island10.setX(island10.getX()+10);
        island11.setX(island11.getX()+10);
        orc.setX(orc.getX()+10);
        orc1.setX(orc1.getX()+10);
        orc2.setX(orc2.getX()+10);
        tresure.setX(tresure.getX()+10);
        tnt.setX(tnt.getX()+10);
        tnt1.setX(tnt1.getX()+10);
        tresure1.setX(tresure1.getX()+10);
        coin1.setX((coin1.getX()+10));
        coin2.setX((coin2.getX()+10));
        coin3.setX((coin3.getX()+10));
        coin4.setX((coin4.getX()+10));
        coin5.setX((coin5.getX()+10));
        coin6.setX((coin6.getX()+10));
        coin7.setX((coin7.getX()+10));
        coin8.setX((coin8.getX()+10));
        coin9.setX((coin9.getX()+10));
        coin10.setX((coin10.getX()+10));
        coin11.setX((coin1.getX()+10));
        coin12.setX((coin2.getX()+10));
        coin13.setX((coin3.getX()+10));
        coin14.setX((coin4.getX()+10));
        coin15.setX((coin5.getX()+10));
        coin16.setX((coin6.getX()+10));
        coin17.setX((coin7.getX()+10));
        coin18.setX((coin8.getX()+10));
        coin19.setX((coin9.getX()+10));
        coin20.setX((coin10.getX()+10));
    }

    myTimer timer= new myTimer();
    public void right(ActionEvent e){
        timer.start();
        System.out.println(storage);
            //hero.setLayoutX((hero.getLayoutX()+10));
          // System.out.println("HERO ->  "+hero.getLayoutX()+" "+hero.getLayoutY());
            System.out.println("Hero  pos ->"+hero.getX()+" "+hero.getY());
            System.out.println("ORC pos-> "+orc1.getX()+" "+orc1.getY());
            DoubleProperty doublePropertyY = hero.translateYProperty();
            DoubleProperty doublePropertyOY = orc1.translateYProperty();
            double temp=doublePropertyY.getValue();
            System.out.println("Hero property y "+(int)temp);
            System.out.println("Orc property y "+doublePropertyOY.getValue());

            hero.setX(hero.getX()+10);
            sword.setX(sword.getX()+10);
            hammer.setX(hammer.getX()+10);
            island1.setX(island1.getX()-10);
            island2.setX(island2.getX()-10);
            island3.setX(island3.getX()-10);
            island4.setX(island4.getX()-10);
            island5.setX(island5.getX()-10);
            island6.setX(island6.getX()-10);
            island7.setX(island7.getX()-10);
            island8.setX(island8.getX()-10);
            island9.setX(island9.getX()-10);
            island10.setX(island10.getX()-10);
            island11.setX(island11.getX()-10);
            orc.setX(orc.getX()-10);
            orc1.setX(orc1.getX()-10);
            orc2.setX(orc2.getX()-10);
            tresure.setX(tresure.getX()-10);
            tresure1.setX(tresure.getX()-10);
            tnt.setX(tnt.getX()-10);
            tnt1.setX(tnt.getX()-10);
            coin1.setX((coin1.getX()-10));
            coin2.setX((coin2.getX()-10));
            coin3.setX((coin3.getX()-10));
            coin4.setX((coin4.getX()-10));
            coin5.setX((coin5.getX()-10));
            coin6.setX((coin6.getX()-10));
            coin7.setX((coin7.getX()-10));
            coin8.setX((coin8.getX()-10));
            coin9.setX((coin9.getX()-10));
            coin10.setX((coin10.getX()-10));
            coin11.setX((coin1.getX()-10));
            coin12.setX((coin2.getX()-10));
            coin13.setX((coin3.getX()-10));
            coin14.setX((coin4.getX()-10));
            coin15.setX((coin5.getX()-10));
            coin16.setX((coin6.getX()-10));
            coin17.setX((coin7.getX()-10));
            coin18.setX((coin8.getX()-10));
            coin19.setX((coin9.getX()-10));
            coin20.setX((coin10.getX()-10));
            my_score+=1;
            myscore.setText("Score : "+Integer.toString(my_score));
            mycoin.setText((Integer.toString(coin_count)));
            RotateTransition atatck = new RotateTransition();
            RotateTransition atatck1= new RotateTransition();
             atatck.setNode(sword);
             atatck.setDuration(Duration.millis(500));
             atatck.setCycleCount(1);
             atatck.setInterpolator(Interpolator.LINEAR);
             atatck.setByAngle(360);
             atatck.setAxis(Rotate.Z_AXIS);
             atatck.play();
            atatck1.setNode(hammer);
            atatck1.setDuration(Duration.millis(500));
            atatck1.setCycleCount(1);
            atatck1.setInterpolator(Interpolator.LINEAR);
            atatck1.setByAngle(360);
            atatck1.setAxis(Rotate.Z_AXIS);
            atatck1.play();


    }
    int coin_count=0;

//    public void attackwepon(int choice){
//        RotateTransition atatck = new RotateTransition();
//        RotateTransition atatck1= new RotateTransition();
//
//        if(choice==1) {
//           atatck.setNode(sword);
//           atatck.setDuration(Duration.millis(500));
//           atatck.setCycleCount(1);
//           atatck.setInterpolator(Interpolator.LINEAR);
//           atatck.setByAngle(360);
//           atatck.setAxis(Rotate.Z_AXIS);
//           atatck.play();
//       }else {
//           atatck1.setNode(hammer);
//           atatck1.setDuration(Duration.millis(500));
//           atatck1.setCycleCount(1);
//           atatck1.setInterpolator(Interpolator.LINEAR);
//           atatck1.setByAngle(360);
//           atatck1.setAxis(Rotate.Z_AXIS);
//           atatck1.play();
//       }
//
//    }
    public void hammerclick(ActionEvent e){
        if(haswepon==1){
            hammer.setVisible(true);
            sword.setVisible(false);
        }
    }
    public void swordclick(ActionEvent e){
        if(haswepon==1){
            sword.setVisible(true);
            hammer.setVisible(false);
        }
    }



    public void collisionOrc(int heroX, int orcX, int heroY, int orcY,int wepon){
        TranslateTransition OrcCollision = new TranslateTransition();
        TranslateTransition OrcCollision1 = new TranslateTransition();
        if (heroX==50 && orcX==-50 && heroY-orcY<5 && heroX<60){
           if(wepon==0) {
               OrcCollision.setNode(orc);
               OrcCollision.setDelay(Duration.millis(2));
               OrcCollision.setCycleCount(1);
               OrcCollision.setDuration(Duration.millis(200));
               OrcCollision.setByX(50);
               OrcCollision.play();
           }
        }else if (heroX==240 && orcX==-240 && heroY-orcY<5 && heroX<260){
            if(wepon==0) {
                OrcCollision1.setNode(orc1);
                OrcCollision1.setDelay(Duration.millis(2));
                OrcCollision1.setCycleCount(1);
                OrcCollision1.setDuration(Duration.millis(200));
                OrcCollision1.setByX(50);
                OrcCollision1.play();
            }else {
                FadeTransition fadeorc = new FadeTransition();
                fadeorc.setNode(orc1);
                fadeorc.setFromValue(1);
                fadeorc.setToValue(-1);
                fadeorc.setCycleCount(1);
                fadeorc.play();
                //orc1.setVisible(false);
            }
        }else if (heroX==370 && orcX==-370 && heroY-orcY<5 && heroX<390){
            if(wepon==0) {
                OrcCollision1.setNode(orc2);
                OrcCollision1.setDelay(Duration.millis(2));
                OrcCollision1.setCycleCount(1);
                OrcCollision1.setDuration(Duration.millis(200));
                OrcCollision1.setByX(50);
                OrcCollision1.play();
            }else {
                FadeTransition fadeorc = new FadeTransition();
                fadeorc.setNode(orc2);
                fadeorc.setFromValue(1);
                fadeorc.setToValue(-1);
                fadeorc.setCycleCount(1);
                fadeorc.play();
                //orc1.setVisible(false);
            }
        }

    }

    public void checkCollision(int heroposX,int heroposY){
        if(heroposX>=120 && heroposX<=140&&heroposY>110){
            tnt.setVisible(false);
        }else if(heroposX>=300&&heroposX<=320 &&heroposY>110){
            tnt1.setVisible(false);
        }
    }
    public void openChest(int heroX,int heroY,int b){

        if(heroX>=180 && heroX<=200 && heroY>110){
            tresure.setImage(new Image("file:///Users/xanirudhsharmax/Desktop/images/ChestOpen.png"));
            if(b==1){
                ishammer.setOpacity(1);
                hammer.setVisible(true);
                haswepon=1;

            }else if (b==0) {
                issword.setOpacity(1);
                sword.setVisible(true);
                haswepon=1;
            }
        }else if(heroX>=410 && heroX<=430 &&  heroY>110 ){
            tresure1.setImage(new Image("file:///Users/xanirudhsharmax/Desktop/images/ChestOpen.png"));
            if(b==1){
                ishammer.setOpacity(1);
                hammer.setVisible(true);
                haswepon=1;

            }else if(b==0) {
                issword.setOpacity(1);
                sword.setVisible(true);
                haswepon=1;
            }

        }
    }


    public void vanish(int x, int y) {
        FadeTransition fadeup = new FadeTransition();
        FadeTransition fadedown = new FadeTransition();
        if (x >= 110.0&& y>=0&&y<=2 && x<=130.0) {
            fadeup.setNode(coin1);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();
            fadeup.setDelay(Duration.millis(500));
          //  coin1.setVisible(false);
            coin_count++;
        }else if (x >= 110.0 && y>=33&&y<=36 && x<=130.0) {
            fadedown.setNode(coin6);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.play();
            fadedown.setDelay(Duration.millis(500));
         //   coin6.setVisible(false);
            coin_count++;
        }else if (x >= 120.0 && y>=0&&y<=2 && x<=140.0) {
            fadeup.setNode(coin2);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();
            fadeup.setDelay(Duration.millis(500));
           // coin2.setVisible(false);
        coin_count++;
        }else if (x >= 120.0 && y>=33&&y<=36 && x<=140.0) {
            fadedown.setNode(coin7);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.setCycleCount(1);
            fadedown.play();
            fadeup.setDelay(Duration.millis(500));
           // coin7.setVisible(false);
            coin_count++;
        }else if (x >= 130.0 && y>=0&&y<=2 && x<=150.0) {
            fadeup.setNode(coin3);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();
            fadeup.setDelay(Duration.millis(500));
           // coin3.setVisible(false);
            coin_count++;
        } else if (x >= 130.0 && y>=33&&y<=36 && x<=150.0) {
            fadedown.setNode(coin8);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.setCycleCount(1);
            fadedown.play();fadeup.setDelay(Duration.millis(500));
//            coin8.setVisible(false);
            coin_count++;
        }else if (x >= 140.0 && y>=0&&y<=2 && x<=160.0) {
            fadeup.setNode(coin4);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();
            fadeup.setDelay(Duration.millis(500));
            //coin4.setVisible(false);
            coin_count++;
        } else if (x >= 140.0 && y>=33&&y<=36 && x<=160.0) {
            fadedown.setNode(coin9);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.setCycleCount(1);
            fadedown.play();fadeup.setDelay(Duration.millis(500));
//            coin9.setVisible(false);
            coin_count++;
        }else if (x >= 150.0 && y>=0&&y<=2 && x<=170.0) {
            fadeup.setNode(coin5);
            fadeup.setFromValue(1);
            fadeup.setToValue(-1);
            fadeup.setCycleCount(1);
            fadeup.play();fadeup.setDelay(Duration.millis(500));
//            coin5.setVisible(false);
            coin_count++;
        } else if (x >= 150.0 && y>=33&&y<=36 && x<=170.0) {
            fadedown.setNode(coin10);
            fadedown.setFromValue(1);
            fadedown.setToValue(-1);
            fadedown.setCycleCount(1);
            fadedown.play();fadeup.setDelay(Duration.millis(500));
//            coin10.setVisible(false);
            coin_count++;
        }
}
public void vanish1(int x,int y){
    FadeTransition fadeup = new FadeTransition();
    FadeTransition fadedown = new FadeTransition();
    if (x >= 450 && x<=470) {
        if (y>= 0 && y<=2 ) {
            coin11.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin16.setVisible(false);
            coin_count++;
        }
    }else if (x >= 460 && x<=480 ){
        if (y>= 0 && y<=2 ) {
            coin12.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin17.setVisible(false);
            coin_count++;
        }
    }else if (x >= 470 && x<=490 ){
        if (y>= 0 && y<=2 ) {
            coin13.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin18.setVisible(false);
            coin_count++;
        }
    }else if (x >= 480 && x<=500 ){
        if (y>= 0 && y<=2 ) {
            coin14.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin19.setVisible(false);
            coin_count++;
        }
    }else if (x >= 490 && x<=510 ){
        if (y>= 0 && y<=2 ) {
            coin15.setVisible(false);
            coin_count++;
        }else if(y>=33&&y<=36) {
            coin20.setVisible(false);
            coin_count++;
        }
    }
}



    int  haswepon=0;
    int random = (int)(Math.random()*(1-0+1)+0);


AnimationTimer collisionTimer = new AnimationTimer() {
        @Override
        public void handle(long now) {
//            checkCollision(hero,coin1);
        }
    };
    double storage;
   int timertime=0;
   private long prevtime;
    long  doublePropertyY;


    private class myTimer extends AnimationTimer{
        @Override
        public void handle(long now) {
            long dt=now-prevtime;
            DoubleProperty doublePropertyhero = hero.translateYProperty();
            DoubleProperty doublePropertyOrc = orc.translateYProperty();
            DoubleProperty doublePropertyOrc1 = orc1.translateYProperty();
              //  System.out.println(doublePropertyY.getValue());
                //timertime++;
            double orcstorage=doublePropertyOrc.getValue();
            double orc1storage=doublePropertyOrc1.getValue();
            storage=doublePropertyhero.getValue();
            //System.out.println(hero.getX());
            System.out.println("hero y : "+(int)storage);
            System.out.println("hero x "+hero.getX());

            //System.out.println("orc: "+doublePropertyOY.getValue());
            vanish((int)hero.getX(),(int)storage);
            vanish1((int)hero.getX(),(int)storage);
            collisionOrc((int)hero.getX(), (int)orc.getX(),(int)storage,(int)orcstorage,haswepon);
            collisionOrc((int)hero.getX(), (int)orc1.getX(),(int)storage,(int)orc1storage,haswepon);
            checkCollision((int)hero.getX(),(int)storage);
            openChest((int)hero.getX(),(int)storage,random);

        }
    }











    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       // MovementController movementController=new MovementController(hero,scene);
//        myTimer timer = new myTimer();
//        timer.start();
        TranslateTransition translate = new TranslateTransition();
        TranslateTransition swordtranslate=new TranslateTransition();
        TranslateTransition hammertranslate=new TranslateTransition();
        TranslateTransition translate1 = new TranslateTransition();
        TranslateTransition translate2 = new TranslateTransition();
        TranslateTransition translate3 = new TranslateTransition();
        TranslateTransition translate4 = new TranslateTransition();
        TranslateTransition translate5 = new TranslateTransition();
        //timer.start();
        translate.setNode(orc);
        translate.setDuration(Duration.millis(600));
        translate.setCycleCount(TranslateTransition.INDEFINITE);
        translate.setByY(90);
        translate.setAutoReverse(true);
        translate.play();

        translate5.setNode(hero);
        translate5.setDuration(Duration.millis(700));
        //translate5.setDelay(Duration.millis(1000));
        translate5.setByY(120);
        translate5.setAutoReverse(true);
        translate5.setCycleCount(TranslateTransition.INDEFINITE);
        translate5.play();
        swordtranslate.setNode(sword);
        swordtranslate.setDuration(Duration.millis(700));
        swordtranslate.setByY(120);
        swordtranslate.setAutoReverse(true);
        swordtranslate.setCycleCount(TranslateTransition.INDEFINITE);
        swordtranslate.play();
        hammertranslate.setNode(hammer);
        hammertranslate.setDuration(Duration.millis(700));
        hammertranslate.setByY(120);
        hammertranslate.setAutoReverse(true);
        hammertranslate.setCycleCount(TranslateTransition.INDEFINITE);
        hammertranslate.play();



        translate1.setNode(orc2);
        translate1.setDuration(Duration.millis(800));
        translate1.setCycleCount(TranslateTransition.INDEFINITE);
        translate1.setByY(90);
        translate1.setAutoReverse(true);
        translate1.play();

        translate2.setNode(orc1);
        translate2.setDuration(Duration.millis(1000));
        translate2.setCycleCount(TranslateTransition.INDEFINITE);
        translate2.setByY(90);
        translate2.setAutoReverse(true);
        translate2.play();

//        System.out.println("hero ->"+hero.getX()+" "+hero.getY());
//        System.out.println("orc ->"+orc.getX()+" "+orc.getY());
//        if(hero.getX()==100 || orc.getX()==-90.0){
//            FadeTransition fade = new FadeTransition();
//            fade.setNode(orc);
//            fade.setFromValue(1);
//            fade.setToValue(0);
//            fade.play();
//        }


//        FadeTransition fade = new FadeTransition();
//            fade.setNode(orc);
//            fade.setFromValue(1);
//            fade.setToValue(0);
//            fade.play();

//        translate3.setNode(island);
//        translate3.setDuration(Duration.millis(2000));
//        translate3.setCycleCount(TranslateTransition.INDEFINITE);
//        translate3.setByY(80);
//        translate3.setAutoReverse(true);
//        translate3.play();
//            collisionTimer.start();
    }

    public void Setting_(ActionEvent event) throws IOException {
        root= FXMLLoader.load(getClass().getResource("settings.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}
